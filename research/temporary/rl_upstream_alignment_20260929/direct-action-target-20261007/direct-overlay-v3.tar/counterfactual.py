"""Sampled reward-event composition for the fixed DT Q/V contract.

DeltaTrace owns the event log likelihood ratios. Rollout owns rewards, event
order, discounts, and policy-token identities. This module only composes those
artifacts; it does not estimate ratios, route observations, or implement PPO.
See PLAN.md for the sampling and support conditions of the estimator.
"""
from __future__ import annotations

from dataclasses import dataclass
from collections.abc import Sequence
from typing import Any
import torch


@dataclass(frozen=True)
class DTTokenCredit:
    """Detached sample estimates, not pointwise exact conditional Q and V."""
    advantages: torch.Tensor
    q_estimates: torch.Tensor
    v_estimates: torch.Tensor


@torch.no_grad()
def reward_event_token_credit(
    log_ratios: torch.Tensor,
    rewards: torch.Tensor,
    future_event_mask: torch.Tensor,
    policy_mask: torch.Tensor,
    *,
    discounts: torch.Tensor | None = None,
    self_target_mask: torch.Tensor | None = None,
) -> DTTokenCredit:
    """Compose sampled terminal/process rewards into individual token advantages.

    log_ratios[b,k,i] = log p_k(y_k) - log p_k_without_i(y_k).
    Each observed y_k is sampled after a_i under the old continuation policy.
    rewards[b,k] is its actual reward. future_event_mask[b,k,i] identifies
    events not yet settled at token i, using rollout event identities. Only
    policy_mask[b,i] positions are actions. Optional discounts[b,k,i] come
    from the same reward clock as PPO.

    self_target_mask[b,k,i] identifies token i as part of that SAME observed
    literal target y_k. Under the specified deletion reference its event
    probability is zero, so that event contributes Q_hat=r, V_hat=0, A_hat=r.
    This replaces its DT term; it is never added to a second attribution of
    the same event. No log(0) or numerical infinite ratio is evaluated.

    Q_hat_i = sum_k discount_ki * r_k
    V_hat_i = sum_k discount_ki * r_k * exp(-d_ki)
    A_hat_i = sum_k discount_ki * r_k * (1 - exp(-d_ki)).

    Exact ratios give the factual-minus-counterfactual reward expectation.
    This equals PPO Q-V when the counterfactual endpoint has the PLAN V
    semantics; conservation alone does not establish that alignment.
    A terminal reward is one event. No cross-token normalization,
    probability-difference substitution, clipping, or learned baseline occurs.
    """
    if log_ratios.ndim != 3 or not log_ratios.is_floating_point():
        raise ValueError("log_ratios must be floating [batch, events, tokens]")
    batch, events, tokens = log_ratios.shape
    if rewards.shape != (batch, events) or not rewards.is_floating_point():
        raise ValueError("rewards must be floating [batch, events]")
    if future_event_mask.shape != log_ratios.shape or future_event_mask.dtype != torch.bool:
        raise ValueError("future_event_mask must be bool [batch, events, tokens]")
    if policy_mask.shape != (batch, tokens) or policy_mask.dtype != torch.bool:
        raise ValueError("policy_mask must be bool [batch, tokens]")
    inputs = [rewards, future_event_mask, policy_mask]
    if self_target_mask is not None:
        if self_target_mask.shape != log_ratios.shape or self_target_mask.dtype != torch.bool:
            raise ValueError("self_target_mask must be bool [batch, events, tokens]")
        inputs.append(self_target_mask)
    if discounts is not None:
        if discounts.shape != log_ratios.shape or not discounts.is_floating_point():
            raise ValueError("discounts must be floating [batch, events, tokens]")
        inputs.append(discounts)
    if any(value.device != log_ratios.device for value in inputs):
        raise ValueError("all reward-event tensors must be on the same device")
    if not bool(torch.isfinite(rewards).all()):
        raise ValueError("environment rewards must be finite")

    # Do not exponentiate observation/padding/past-event values. Zero-reward
    # events contribute zero and do not need a numerical likelihood ratio.
    active = future_event_mask & policy_mask[:, None, :] & (rewards[:, :, None] != 0)
    dtype = torch.promote_types(log_ratios.dtype, rewards.dtype)
    if discounts is not None:
        dtype = torch.promote_types(dtype, discounts.dtype)
        values = discounts[active]
        if not bool((torch.isfinite(values) & (values >= 0)).all()):
            raise ValueError("active discounts must be finite and nonnegative")
        active = active & (discounts > 0)
    estimated = active if self_target_mask is None else active & ~self_target_mask
    if not bool(torch.isfinite(log_ratios[estimated]).all()):
        raise ValueError("active event log ratios must be finite; do not smooth away missing support")
    if dtype in (torch.float16, torch.bfloat16):
        dtype = torch.float32
    d = torch.where(estimated, log_ratios.to(dtype), 0.0)
    weighted_reward = torch.where(active, rewards.to(dtype)[:, :, None], 0.0)
    if discounts is not None:
        weighted_reward = weighted_reward * torch.where(active, discounts.to(dtype), 0.0)

    # Stable near d=0: sampled importance correction, not R*(p_action-p_policy).
    event_advantages = weighted_reward * (-torch.expm1(-d))
    event_baselines = weighted_reward * torch.exp(-d)
    if self_target_mask is not None:
        event_advantages = torch.where(self_target_mask, weighted_reward, event_advantages)
        event_baselines = torch.where(self_target_mask, 0.0, event_baselines)
    advantages = event_advantages.sum(dim=1)
    q_estimates = weighted_reward.sum(dim=1)
    v_estimates = event_baselines.sum(dim=1)
    if not all(bool(torch.isfinite(value).all()) for value in (advantages, q_estimates, v_estimates)):
        raise FloatingPointError("reward-event estimate overflow; no silent ratio clamp is applied")
    return DTTokenCredit(advantages, q_estimates, v_estimates)


def episode_returns(rows: Sequence[dict[str, Any]]) -> list[float]:
    """One reverse cumsum of original active rewards, gamma=1 as in PLAN.md.

    This is the representation boundary from environment rows to the sampled
    return outcome. No environment scoring, GAE, normalization or value model.
    """
    if not rows:
        raise ValueError('an episode requires original rollout rows')
    steps = [int(row['env_step']) for row in rows if bool(row['active_masks'])]
    if any(b <= a for a, b in zip(steps, steps[1:])):
        raise ValueError('reward events must retain unique increasing environment step identities')
    if any(row['traj_uid'] != rows[0]['traj_uid'] for row in rows):
        raise ValueError('rows from different trajectories cannot share returns')
    rewards = torch.tensor([float(row['rewards']) if bool(row['active_masks']) else 0.0
                            for row in rows], dtype=torch.float64)
    if not bool(torch.isfinite(rewards).all()):
        raise ValueError('official active rewards must be finite')
    future = rewards.flip(0).cumsum(0).flip(0).tolist()
    # VERL's reward manager assigns the episode score to each response, then
    # applies its own current-response penalty. The trainer supplies that
    # exact difference; do not rescore invalid actions or sum their penalties
    # again over future rows. Past environment rewards remain excluded.
    return [value + float(row.get('dt_reward_adjustment', 0.0))
            if bool(row['active_masks']) else value
            for row, value in zip(rows, future)]


@torch.no_grad()
def return_credit_for_episode(
    rows: Sequence[dict[str, Any]],
    return_log_ratios: Sequence[torch.Tensor],
) -> list[dict[str, torch.Tensor]]:
    """One return-event vector per original response; reuse the Q/V primitive."""
    if not rows or len(rows) != len(return_log_ratios):
        raise ValueError('one return log-ratio vector is required per original rollout row')
    return return_credit_for_rows(rows, return_log_ratios, episode_returns(rows))


@torch.no_grad()
def return_credit_for_rows(rows, return_log_ratios, returns):
    """Compose rows with complete returns prepared before distributed splitting."""
    if not (len(rows) == len(return_log_ratios) == len(returns)):
        raise ValueError('one complete return and log-ratio vector are required per row')
    output = []
    for row, ratios, value in zip(rows, return_log_ratios, returns):
        response = row["responses"]
        if response.ndim != 1 or response.numel() == 0:
            raise ValueError("an original rollout response must be a nonempty 1-D tensor")
        width = response.numel()
        if ratios.shape != (width,):
            raise ValueError('return log ratios must align with original response tokens')
        attention = row["attention_mask"]
        if attention.ndim != 1 or attention.numel() < width:
            raise ValueError("rollout attention mask must include the complete response")
        policy = attention[-width:].to(device=ratios.device, dtype=torch.bool)
        policy = policy & bool(row["active_masks"])
        future = torch.ones((1, 1, width), device=ratios.device, dtype=torch.bool)
        rewards = torch.tensor([[value]], device=ratios.device, dtype=torch.float32)
        credit = reward_event_token_credit(
            ratios[None, None, :], rewards, future, policy.unsqueeze(0),
        )
        output.append({
            "dt_token_advantages": credit.advantages[0],
            "dt_q_estimates": credit.q_estimates[0],
            "dt_v_estimates": credit.v_estimates[0],
        })
    return output


def assert_token_advantage_contract(
    advantages: torch.Tensor,
    response_mask: torch.Tensor,
    *,
    atol: float = 1e-6,
) -> None:
    """Validate the existing upstream PPO tensor boundary."""
    if advantages.shape != response_mask.shape:
        raise ValueError("token advantages and response_mask must have equal shapes")
    if response_mask.dtype != torch.bool:
        raise ValueError("response_mask must be bool")
    if not bool(torch.isfinite(advantages).all()):
        raise ValueError("token advantages must be finite")
    if bool((advantages[~response_mask].abs() > atol).any()):
        raise ValueError("token advantages must be zero outside the policy mask")
